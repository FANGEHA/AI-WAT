from mysql.entity.Camera import Camera
from mysql.mapper.base.BaseMapper import BaseMapper


class CameraMapper(BaseMapper):
    def __init__(self):
        BaseMapper.__init__(self, Entity=Camera)
