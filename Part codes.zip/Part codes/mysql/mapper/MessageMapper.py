from mysql.entity.Message import Message
from mysql.mapper.base.BaseMapper import BaseMapper


class MessageMapper(BaseMapper):
    def __init__(self):
        BaseMapper.__init__(self, Entity=Message)

