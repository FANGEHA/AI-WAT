from mysql.SqlWorker import SqlWorker
from mysql.wrapper.QueryWrapper import QueryWrapper
from mysql.wrapper.UpdateWrapper import UpdateWrapper
from typing import Any, List, Dict
from config import host, user, passwd


class BaseMapper(object):
    """
    BaseMapper contains methods for base operation to MySQL:
        insert(entity)
        delete(query_wrapper)
        update(update_wrapper)
        select(query_wrapper)
        select_one(query_wrapper)
        exist(query_wrapper)
        count(query_wrapper)
    """

    def __init__(self, Entity):
        self.sql_worker = SqlWorker(host=host, user=user, passwd=passwd)
        self.Entity = Entity

    def insert(self, entity: Any) -> Any:
        print('[insert]', end=' ')
        print(entity)
        con = self.sql_worker.create_connection()
        cur = con.cursor()
        insert_columns = entity.get_keys()
        insert_values = ["'{}'".format(value) for value in entity.get_values()]
        cur.execute(
            'insert into {} {} values {};'.format(
                self.Entity().name,
                '(' + ','.join(insert_columns) + ')',
                '(' + ','.join(insert_values) + ')'
            ))
        con.commit()
        con.close()
        return entity

    def delete(self, query_wrapper: QueryWrapper) -> None:
        con = self.sql_worker.create_connection()
        cur = con.cursor()
        cur.execute(
            'delete from {} where {};'.format(
                self.Entity().name,
                query_wrapper.get_sql_statement()))
        con.commit()
        con.close()

    def update(self, update_wrapper: UpdateWrapper, query_wrapper: QueryWrapper) -> None:
        con = self.sql_worker.create_connection()
        cur = con.cursor()
        cur.execute(
            'update {} set {} where {};'.format(
                self.Entity().name,
                update_wrapper.get_sql_statement(),
                query_wrapper.get_sql_statement()
            )
        )
        con.commit()
        con.close()

    def select(self, query_wrapper: QueryWrapper) -> List[Any]:
        con = self.sql_worker.create_connection()
        cur = con.cursor()
        cur.execute(
            'select * from {} where {};'.format(
                self.Entity().name,
                query_wrapper.get_sql_statement()))
        data_list = cur.fetchall()
        entity_list = [self.Entity().init(self.Entity().name, self.Entity().keys, lis) for lis in data_list]
        con.close()
        return entity_list

    def select_one(self, query_wrapper: QueryWrapper) -> Any:
        entity_list = self.select(query_wrapper)
        return entity_list[0] if len(entity_list) == 1 else self.Entity()

    def exist(self, query_wrapper: QueryWrapper) -> bool:
        return len(self.select(query_wrapper)) > 0

    def count(self, query_wrapper: QueryWrapper) -> int:
        return len(self.select(query_wrapper))

    def select_dict(self, query_wrapper: QueryWrapper) -> List[Dict[str, str]]:
        entity_list = self.select(query_wrapper)
        return [entity.json() for entity in entity_list]
