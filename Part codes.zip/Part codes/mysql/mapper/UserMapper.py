from mysql.entity.User import User
from mysql.mapper.base.BaseMapper import BaseMapper


class UserMapper(BaseMapper):
    def __init__(self):
        BaseMapper.__init__(self, Entity=User)

