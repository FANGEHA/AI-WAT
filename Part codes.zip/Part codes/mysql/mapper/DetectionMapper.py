from pandas import DataFrame

from mysql.entity.Detection import Detection
from mysql.mapper.base.BaseMapper import BaseMapper
from mysql.wrapper.QueryWrapper import QueryWrapper


class DetectionMapper(BaseMapper):
    def __init__(self):
        BaseMapper.__init__(self, Entity=Detection)

    def select_data_frame(self, query_wrapper: QueryWrapper) -> DataFrame:
        detections = self.select(query_wrapper)
        data_frame = DataFrame(
            data=[detection.values for detection in detections],
            columns=self.Entity().get_keys()
        )
        return data_frame
