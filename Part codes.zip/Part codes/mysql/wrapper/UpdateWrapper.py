from typing import List, Tuple


class UpdateWrapper(object):
    """
    QueryWrapper translate list[tuple] into sql statement.
    list[tuple] is called 'settings', like [(col, val), ]
    """

    def __init__(self, settings: List[Tuple[str, str]] = None):
        self.settings = [] if settings is None else settings

    def set_settings(self, settings: List[Tuple[str, str]]) -> None:
        self.settings = settings

    def append(self, setting: Tuple[str, str]) -> None:
        self.settings.append(setting)

    def clear(self) -> None:
        self.settings.clear()

    def get_sql_statement(self) -> str:
        settings = []
        for col, val in self.settings:
            settings.append('{} = "{}"'.format(col, val))
        assert len(settings) > 0
        sql_statement = ', '.join(settings)
        return sql_statement
