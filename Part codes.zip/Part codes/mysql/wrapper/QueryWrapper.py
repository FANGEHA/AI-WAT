from typing import List, Tuple


class QueryWrapper(object):
    """
    QueryWrapper translate list[tuple] into sql statement.
    list[tuple] is called 'constraint', like [(col, op, val), ]
    """

    def __init__(self, constraints: List[Tuple[str, str, str]] = None):
        self.constraints = [] if constraints is None else constraints
        self.operators = {
            'eq': '=',
            'neq': '!=',
            'le': '<=',
            'lt': '<',
            'ge': '>=',
            'gt': '>',
        }

    def set_constraint(self, constraints: List[Tuple[str, str, str]]) -> None:
        self.constraints = constraints

    def append(self, constraint: Tuple[str, str, str]) -> None:
        self.constraints.append(constraint)

    def clear(self) -> None:
        self.constraints.clear()

    def get_sql_statement(self) -> str:
        constraints = []
        for col, op, val in self.constraints:
            constraints.append('{} {} "{}"'.format(col, self.operators[op], val))
        sql_statement = ' and '.join(constraints) if len(constraints) else ' 1 '
        return sql_statement
