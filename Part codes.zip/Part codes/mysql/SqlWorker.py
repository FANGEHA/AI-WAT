import pymysql
from mysql.entity.Detection import Detection
from mysql.entity.Message import Message
from mysql.entity.Camera import Camera
from mysql.entity.User import User


class SqlWorker(object):
    """
    if using local MySQL, before you instantiate SqlWorker, you should:
        1. Open cmd as administrator.
        2. start MySQL using 'net start mysql'. (close it using 'net stop mysql')
    """
    def __init__(self, host, user, passwd):
        self.host = host
        self.host = '124.223.59.96'
        self.user = user
        self.passwd = passwd

    def init(self):
        """
        initialize database, table in MySQL.
        """
        con = self.create_connection()
        cur = con.cursor()

        # create tables from entity.
        entity_list = [
            Detection(),
            Message(),
            Camera(),
            User()
        ]
        for entity in entity_list:
            cur.execute('drop table if exists {};'.format(entity.name))
            create_column_state = []

            for column in entity.get_keys():
                create_column_state.append('{} varchar(200)'.format(column))
            cur.execute('create table {} ({});'.format(entity.name, ', '.join(create_column_state)))

        con.commit()
        con.close()

    def create_connection(self):
        return pymysql.connect(host=self.host,
                               user=self.user,
                               passwd=self.passwd,
                               port=3306,
                               database='wat',
                               charset='utf8')
