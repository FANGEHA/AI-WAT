from mysql.entity.base.Entity import Entity


class Message(Entity):
    def __init__(self,
                 idx=None,
                 type_=None,
                 title=None,
                 content=None,
                 publisher=None,
                 datetime=None):
        name = 'message'
        keys = ['idx', 'type', 'title', 'content', 'publisher', 'datetime']
        values = [idx, type_, title, content, publisher, datetime]

        Entity.__init__(self, name, keys, values)
