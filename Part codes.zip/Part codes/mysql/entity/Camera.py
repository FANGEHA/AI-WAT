from mysql.entity.base.Entity import Entity
from numpy import ndarray
from typing import Tuple
import cv2


class Camera(Entity):
    def __init__(self,
                 idx=None,
                 name=None,
                 river=None,
                 ip=None):
        keys = ['idx', 'name', 'river', 'ip']
        values = [idx, name, river, ip]
        name = 'river'

        self.cap = None

        Entity.__init__(self, name, keys, values)

    def create_video_capture(self):
        # self.cap = cv2.VideoCapture(
        #     "rtsp://admin:ai12345@@{}/cam/realmonitor?channel=1&subtype=1?tcp".format(
        #         self.get('ip')
        #     ))
        video_file_name = {
            '海湾中心河': 'hwzxh.mp4',
            '海农公路海马路北': 'hlglhmlb.mp4',
            '白沙路莲塘路桥东': 'bslltlqd.mp4',
            '星疆路随塘河路南': 'xjlsthln.mp4',
        }
        self.cap = cv2.VideoCapture('static/video/{}'.format(video_file_name[self.get('river')]))

    def get_frame(self) -> Tuple[bool, ndarray]:
        """
            视频传输到网页延迟问题：
            因为rtsp这种协议就是会一帧一帧把所有数据传递过去，改小流量就行.(降低帧数)
        """
        # print('Camera.get_frame()')
        assert not (self.cap is None)
        ret, frame = self.cap.read()
        if ret is False:
            self.create_video_capture()
            ret, frame = self.cap.read()
        # # ret: bool, whether the video file is read to the end.
        return ret, frame
