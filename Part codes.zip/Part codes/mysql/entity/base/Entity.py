from typing import List, Dict


class Entity(object):
    """
    Entity contains base methods for table item.
    """

    def __init__(self, name: str = None, keys: List[str] = None, values: List[str] = None):
        self.name = name
        self.keys = keys
        self.values = values
        self.data = dict(zip(keys, values))

    def init(self, name: str, keys: List[str], values: List[str]):
        self.name = name
        self.keys = keys
        self.values = values
        self.data = dict(zip(keys, values))
        return self

    def create_from_dict(self, dic: Dict[str, str]):
        self.data = dic
        self.values = [dic.get(key) for key in self.keys]
        return self

    def get_keys(self) -> List[str]:
        return self.keys

    def get_values(self) -> List[str]:
        return self.values

    def json(self) -> Dict[str, str]:
        return self.data

    def get_name(self) -> str:
        return self.name

    def get(self, key: str) -> str:
        assert key in self.data
        return self.data[key]

    def __repr__(self) -> str:
        s = []
        for key, value in zip(self.keys, self.values):
            s.append('{}: {}'.format(key, value))
        return ', '.join(s)

    def empty(self) -> bool:
        return self.name is None and self.keys is None and self.values is None
