from mysql.entity.base.Entity import Entity


class User(Entity):
    def __init__(self,
                 idx=None,
                 username=None,
                 password=None,
                 type_=None,
                 permiss=None):
        keys = ['idx', 'username', 'password', 'type', 'permiss']
        values = [idx, username, password, type_, permiss]
        name = 'user'
        Entity.__init__(self, name, keys, values)
