from mysql.entity.base.Entity import Entity


class Detection(Entity):
    def __init__(self,
                 idx=None,
                 label=None,
                 river=None,
                 datetime=None,
                 remark=None,
                 confidence=None,
                 position=None,
                 relative_size=None,
                 handle_state=None,
                 warning_state=None,
                 image_url=None
                 ):
        name = 'detection'
        keys = ['idx', 'label', 'river', 'datetime', 'remark', 'confidence',
                'position', 'relativeSize', 'handleState', 'warningState', 'imageUrl']
        values = [idx, label, river, datetime, remark, confidence,
                  position, relative_size, handle_state, warning_state, image_url]

        Entity.__init__(self, name, keys, values)

