from PIL.Image import Image, fromarray
import numpy as np
from yolo.yolo import YOLO
from typing import Tuple, List
from numpy import ndarray


class DetectResult(object):
    def __init__(self,
                 box: Tuple[float, float, float, float],
                 score: float,
                 label: str):
        self.box = (
            round(box[0], 2),
            round(box[1], 2),
            round(box[2], 2),
            round(box[3], 2)
        )  # top, left, bottom, right
        self.score = score
        self.label = label

    def get_box_str(self) -> str:
        return ','.join(map(str, self.box))

    def get_relative_size(self) -> str:
        top, left, bottom, right = self.box
        return '{:0>5.2f}'.format((bottom - top) * (right - left) / (640 * 640) * 100)

    def __repr__(self) -> str:
        return 'box: {}\nscore: {}\nlabel: {}'.format(self.box, self.score, self.label)

    def eval_warning_state(self):
        return '预警' if float(self.get_relative_size()) > 15 else '正常'


class ImageDetector(object):
    def __init__(self):
        self.yolo = YOLO()
        self.crop = False
        self.count = False

    def detect(self, image_array: ndarray) -> Tuple[Image, List[DetectResult]]:
        r_image: Image = fromarray(image_array, 'RGB')
        image, out_boxes, out_scores, predicted_labels = self.yolo.detect_image(r_image, crop=self.crop,
                                                                                count=self.count)
        result_list: List[DetectResult] = [
            DetectResult(
                box=tuple(out_boxes[i].numpy().tolist()),
                score=out_scores[i],
                label=predicted_labels[i]
            ) for i in range(len(out_scores))
        ]
        return image, result_list


def euclidean_distance(array1, array2):
    return np.sqrt(np.sum(np.square(array1 - array2)))

# class ContinuousDetector(object):
#     def __init__(self):
#         self.time_interval = 3
#         self.space_interval = 200
#         self.last_time = 0
#         self.last_time_catches = []
#         self.detector = ImageDetector()
#
#     def detect(self, image_array):
#         r_image, out_boxes, out_scores, predicted_labels = self.detector.detect(image_array)
#         tem_catches = []
#         if self.last_time != 0:  # need to check
#             for current_box, current_score, current_label in zip(out_boxes, out_scores, predicted_labels):
#                 find = False
#                 for last_box, last_score, last_label in self.last_time_catches:
#                     if current_label != last_label:
#                         continue
#                     if time.time() - self.last_time > self.time_interval:
#                         continue
#                     if euclidean_distance(np.array(current_box), np.array(last_box)) < self.space_interval:
#                         find = True
#                         break
#                 if find is False:
#                     tem_catches.append((current_box, current_score, current_label))
#         else:
#             for current_box, current_score, current_label in zip(out_boxes, out_scores, predicted_labels):
#                 tem_catches.append((current_box, current_score, current_label))
#
#         self.last_time = time.time()
#         self.last_time_catches = tem_catches
#
#         return self.last_time, r_image, self.last_time_catches
