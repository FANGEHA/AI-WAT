from mysql.mapper.UserMapper import UserMapper
from mysql.wrapper.QueryWrapper import QueryWrapper
from mysql.wrapper.UpdateWrapper import UpdateWrapper
from mysql.entity.User import User
from mysql.entity.base import Entity
from service.Tool.FunctionTools import get_random_seq
from typing import Dict, List, Union, Any


class UserService(object):
    def __init__(self, base_url: str, image_path: str):
        self.base_url = base_url
        self.image_path = image_path
        self.user_mapper = UserMapper()

        # create super admin if not exits.
        if len(self.user_mapper.select(QueryWrapper([('username', 'eq', 'super')]))) == 0:
            self.create_new_user(username='super',
                                 password='123',
                                 type_='admin')

    def create_new_user(self, username: str, password: str, type_: str) -> Entity:
        return self.user_mapper.insert(User(
            idx=get_random_seq('user'),
            username=username,
            password=password,
            type_=type_,
            permiss='1'
        ))

    def validate_user(self, username: str, password: str) -> Dict[str, str]:
        query_wrapper = QueryWrapper([
            ('username', 'eq', username),
            ('password', 'eq', password)
        ])
        user: User = self.user_mapper.select_one(query_wrapper)
        return {
            'token': '' if user.empty() else get_random_seq('iw'),
        }

    def get_user_list(self) -> List[Dict[str, str]]:
        user_list: List[User] = self.user_mapper.select(QueryWrapper())
        users_json = [user.json() for user in user_list]
        return users_json

    def edit_user_type(self, username: str, new_type: str) -> None:
        query_wrapper = QueryWrapper([('username', 'eq', username)])
        update_wrapper = UpdateWrapper([('type', new_type)])
        self.user_mapper.update(update_wrapper, query_wrapper)

    def del_user(self, username: str) -> None:
        query_wrapper = QueryWrapper([('username', 'eq', username)])
        self.user_mapper.delete(query_wrapper)

    def edit_user_password(self, username: str, new_password: str) -> None:
        query_wrapper = QueryWrapper([('username', 'eq', username)])
        update_wrapper = UpdateWrapper([('password', new_password)])
        self.user_mapper.update(update_wrapper, query_wrapper)

    def edit_user_image(self, username: str, new_user_image_url: str) -> None:
        query_wrapper = QueryWrapper([('username', 'eq', username)])
        update_wrapper = UpdateWrapper([('imageUrl', new_user_image_url)])
        self.user_mapper.update(update_wrapper, query_wrapper)
