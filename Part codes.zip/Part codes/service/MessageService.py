from mysql.mapper.MessageMapper import MessageMapper
from mysql.entity.Message import Message
from mysql.wrapper.QueryWrapper import QueryWrapper
from typing import List, Dict
from service.Tool.FunctionTools import get_formatted_time, get_random_seq


class MessageService(object):
    def __init__(self):
        self.message_mapper = MessageMapper()

    def get_handle_opinion(self) -> List[Dict[str, str]]:
        handle_opinion_list: List[Message] = self.message_mapper.select(QueryWrapper([
            ('type', 'eq', 'handleOpinion')
        ]))
        handle_opinion_dicts = [handle_opinion.json() for handle_opinion in handle_opinion_list]
        return handle_opinion_dicts

    def get_sys_info(self) -> List[Dict[str, str]]:
        sys_info_list: List[Message] = self.message_mapper.select(QueryWrapper([
            ('type', 'eq', 'sysInfo')
        ]))
        sys_info_dicts = [sys_info.json() for sys_info in sys_info_list]
        return sys_info_dicts

    def insert_message(self, username: str, type_: str, title: str, content: str) -> Dict[str, str]:
        message: Message = self.message_mapper.insert(Message(
            idx=get_random_seq('msg'),
            type_=type_,
            title=title,
            content=content,
            publisher=username,
            datetime=get_formatted_time()
        ))
        return message.json()
