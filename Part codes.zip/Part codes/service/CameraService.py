from mysql.mapper.CameraMapper import CameraMapper
from mysql.wrapper.QueryWrapper import QueryWrapper
from typing import List, Dict, Tuple
from mysql.entity.Camera import Camera
from service.Tool.FunctionTools import get_formatted_time, get_random_seq
from numpy import ndarray


class CameraService(object):
    def __init__(self):
        self.camera_mapper = CameraMapper()

        # Init camera list.
        self.camera_list: List[Camera] = self.camera_mapper.select(QueryWrapper())
        for camera in self.camera_list:
            camera.create_video_capture()
        self.camera_dict = dict()
        for camera in self.camera_list:
            self.camera_dict[camera.get('idx')] = camera

        self.now_camera_idx = None if len(self.camera_list) == 0 else self.camera_list[0].get('idx')

    def get_camera_dict_list(self) -> List[Dict[str, str]]:
        camera_dict_list = [camera.json() for camera in self.camera_list]
        return camera_dict_list

    def insert_camera(self, name: str, river: str, ip: str) -> None:
        if not self.camera_mapper.exist(QueryWrapper([
            ('name', 'eq', name),
            # ('position', 'eq', position),
            # ('ip', 'eq', ip)
        ])):
            camera = Camera(
                idx=get_random_seq('camera-device'),
                name=name,
                river=river,
                ip=ip
            )
            self.camera_mapper.insert(camera)
            # refresh self.camera_dict
            self.camera_dict[camera.get('idx')] = camera
            self.camera_list.append(camera)
            print('add camera: {}'.format(camera))

    def get_frame(self, idx: str) -> Tuple[bool, ndarray]:
        if idx not in self.camera_dict:
            return False, ndarray((1, 1))
        return self.camera_dict[idx].get_frame()

    def change_camera(self, new_idx: str):
        print('change camera idx from {} to {}'.format(self.now_camera_idx, new_idx))
        self.now_camera_idx = new_idx

