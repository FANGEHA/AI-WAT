from mysql.entity.User import User
from typing import Dict
from mysql.mapper.UserMapper import UserMapper
from mysql.wrapper.QueryWrapper import QueryWrapper
import time


class CacheService(object):
    def __init__(self):
        self.user_dict: Dict[str, User] = dict()
        self.user_mapper = UserMapper()
        self.born_time = dict()
        self.life_time = 60 * 60 * 24 * 3

    def add(self, token: str, username: str):
        user = self.user_mapper.select_one(QueryWrapper([
            ('username', 'eq', username)
        ]))
        self.user_dict[token] = user
        self.born_time[token] = time.time()

        # 清理过期 缓存
        for token in self.born_time:
            if time.time() - self.born_time[token] > self.life_time:
                del self.born_time[token]
                del self.user_dict[token]

    def contain(self, token: str):
        return token in self.user_dict

    def get_user_by_token(self, token: str) -> User:
        if token not in self.user_dict:
            return User()

        # 返回 token 对应的 User
        return self.user_dict[token]
