import random

import numpy as np
import cv2
from service.Tool.FunctionTools import get_random_seq
from service.Tool.ImgAugTools import DataAugmentForObjectDetection, ToolHelper
import os
from PIL.Image import Image
from typing import Tuple, List
import shutil

class ImageService(object):
    def __init__(self, base_url, image_path, dataset_path):
        self.base_url = base_url
        self.image_path = image_path
        self.dataset_path = dataset_path
        self.data_aug = DataAugmentForObjectDetection()
        self.tool_helper = ToolHelper()

    def save_image(self, filename_prefix: str, r_image: Image) -> Tuple[str, str]:
        img_index = get_random_seq(prefix='img')
        path = self.image_path + '/{}.png'.format(filename_prefix + img_index)
        r_image.save(path)
        return self.base_url + path, img_index

    def get_source_img_path(self, username):
        print(username)
        return self.dataset_path + '\\' + 'upload' + '\\' + username + '\\' + 'img'

    def get_save_img_path(self, username):
        return self.dataset_path + '\\' + 'augment' + '\\' + username + '\\' + 'img'

    def get_source_xml_path(self, username):
        return self.dataset_path + '\\' + 'upload' + '\\' + username + '\\' + 'xml'

    def get_save_xml_path(self, username):
        return self.dataset_path + '\\' + 'augment' + '\\' + username + '\\' + 'xml'

    def save_dataset_img(self, username: str, r_image: Image, xml_label) -> Tuple[str, str]:
        source_img_path = self.get_source_img_path(username)
        source_xml_path = self.get_source_xml_path(username)

        # save img
        img_index = get_random_seq(prefix='img')
        path = source_img_path + '\\' + '{}.png'.format(img_index)
        r_image.save(path)

        # save xml
        # using example
        with open(source_xml_path + '\\' + '{}.xml'.format(img_index), 'w') as f:
            with open('static/xml_example.xml', 'r') as f0:
                f.write(f0.read())

        return self.base_url + path, img_index

    def get_img_list(self, username: str):
        source_img_path = self.get_source_img_path(username)
        res = []
        for name in os.listdir(source_img_path):
            res.append(self.base_url + source_img_path + '/' + name)
        print('get_img_list: ', res)
        return res

    def get_augment_img_list(self, username: str):
        source_img_path = self.get_save_img_path(username)
        res = []
        for name in os.listdir(source_img_path):
            res.append(self.base_url + source_img_path + '/' + name)
        return res

    def save_augment(self, username):
        pass

    def augment(self, username, augment_type, extent):
        self.data_aug.set_param(augment_type, extent)
        is_end_with_dot = True  # .jpg or .png

        source_img_path = self.get_source_img_path(username)
        save_img_path = self.get_save_img_path(username)

        source_xml_path = self.get_source_xml_path(username)
        save_xml_path = self.get_save_xml_path(username)

        shutil.rmtree(save_img_path)
        shutil.rmtree(save_xml_path)

        os.mkdir(save_img_path)
        os.mkdir(save_xml_path)

        for parent, _, files in os.walk(source_img_path):
            files.sort()
            for file in files:
                pic_path = os.path.join(parent, file)
                xml_path = os.path.join(source_xml_path, file[:-4] + '.xml')
                values = self.tool_helper.parse_xml(xml_path)  # 解析得到box信息，格式为[[x_min,y_min,x_max,y_max,name]]
                coords = [v[:4] for v in values]  # 得到框
                labels = [v[-1] for v in values]  # 对象的标签

                # 如果图片是有后缀的
                if is_end_with_dot:
                    # 找到文件的最后名字
                    dot_index = file.rfind('.')
                    _file_prefix = file[:dot_index] + str(random.random())  # 文件名的前缀
                    _file_suffix = file[dot_index:]  # 文件名的后缀
                img = cv2.imread(pic_path)

                auged_img, auged_bboxes = self.data_aug.dataAugment(img, coords)
                auged_bboxes_int = np.array(auged_bboxes).astype(np.int32)
                height, width, channel = auged_img.shape  # 得到图片的属性
                img_name = '{}{}'.format(_file_prefix, _file_suffix)  # 图片保存的信息
                self.tool_helper.save_img(img_name, save_img_path,
                                          auged_img)  # 保存增强图片
                self.tool_helper.save_xml('{}.xml'.format(_file_prefix),
                                          save_xml_path, (save_img_path, img_name), height, width, channel,
                                          (labels, auged_bboxes_int))  # 保存xml文件
                print('augment ok -- {}'.format(img_name))
        print('augment is done.')
        self.data_aug.reset_param()
