1. service 中函数的 输入、输出 均为不规则数据
2. controller （路由）中不需要处理 数据结构 内容，都放在 service 中处理。


