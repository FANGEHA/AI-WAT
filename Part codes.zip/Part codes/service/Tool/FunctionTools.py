import time
import random


def get_formatted_time() -> str:
    return str(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))


def get_random_seq(prefix: str) -> str:
    return prefix + (str(time.time())[4:] + str(random.random())[:6]).replace('.', '')[-14:]




