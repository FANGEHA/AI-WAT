from mysql.mapper.DetectionMapper import DetectionMapper
from mysql.mapper.CameraMapper import CameraMapper
from mysql.wrapper.QueryWrapper import QueryWrapper
from mysql.wrapper.UpdateWrapper import UpdateWrapper
from mysql.entity.Detection import Detection
import pandas as pd
from service.Tool.FunctionTools import get_formatted_time, get_random_seq
from typing import List, Dict, Any
from pandas import DataFrame
from service.ImageService import ImageService
from yolo.MyDection import DetectResult
from PIL.Image import Image


class DetectionService(object):
    def __init__(self, base_url, image_path, dataset_path):
        self.detection_mapper = DetectionMapper()
        self.camera_mapper = CameraMapper()
        self.base_url = base_url
        self.image_path = image_path
        self.image_service = ImageService(base_url, image_path, dataset_path)

    def insert_detection(self,
                         label: str,
                         river: str,
                         confidence: str,
                         position: str,
                         relative_size: str,
                         handle_state: str,
                         image_url: str) -> Dict[str, str]:
        detection: Detection = self.detection_mapper.insert(Detection(
            idx=get_random_seq(prefix='detect'),
            label=label,
            river=river,
            datetime=get_formatted_time(),
            confidence=confidence,
            position=position,
            relative_size=relative_size,
            handle_state=handle_state,
            image_url=image_url
        ))
        return detection.json()

    def insert_detect_result_list(self, image: Image, result_list: List[DetectResult], river: str) -> None:
        for result in result_list:
            image_url, img_index = self.image_service.save_image(image)
            self.insert_detection(
                label=result.label,
                river=river,
                confidence=str(result.score),
                position=','.join(map(str, result.box)),
                relative_size=result.get_relative_size(),
                handle_state='未处理',
                image_url=image_url
            )

    def del_detection_item(self, idx: str) -> None:
        query_wrapper = QueryWrapper([
            ('idx', 'eq', idx)
        ])
        self.detection_mapper.delete(query_wrapper)

    def edit_detection_item(self,
                            idx: str,
                            label: str,
                            remark: str,
                            handle_state: str) -> Dict[str, str]:
        query_wrapper = QueryWrapper([
            ('idx', 'eq', idx)
        ])
        update_wrapper = UpdateWrapper([
            ('label', label),
            ('remark', remark),
            ('handleState', handle_state),
            ('datetime', get_formatted_time())
        ])
        self.detection_mapper.update(update_wrapper, query_wrapper)
        updated_detection: Detection = self.detection_mapper.select(query_wrapper)[0]
        return updated_detection.json()

    def get_log_list(self) -> List[Dict[str, str]]:
        detection_list: List[Detection] = self.detection_mapper.select(QueryWrapper())
        detection_list.reverse()
        log_count = 5
        log_list = [{
            'label': detection.get('label'),
            'warningState': detection.get('warningState'),
            'datetime': detection.get('datetime')
        } for detection in detection_list[:log_count]]
        return log_list

    def get_filtered_data_frame(self, constraint: Dict[str, List[str]]) -> DataFrame:
        """
        constraint:
            river: List[str],
            timeRange: List[str] # like ['2023-01-04T16:00:00.000Z', '2023-02-05T16:00:00.000Z']
            examples
            {'river': ['逸夫楼河道'], 'time_range': ''}
            {'river': ['逸夫楼河道'], 'time_range': ['2023-01-03T16:00:00.000Z', '2023-02-20T16:00:00.000Z']}
        """
        detection_data_frame: DataFrame = self.detection_mapper.select_data_frame(QueryWrapper())
        # Screening place.
        detection_data_frame = detection_data_frame[detection_data_frame['river'].isin(constraint['riverList'])]
        # Screening time.
        start_time = pd.to_datetime('2000-01-01')
        end_time = pd.to_datetime('2080-01-01')
        if len(constraint['timeRange']) > 0:
            start_time = pd.to_datetime(constraint['timeRange'][0][:10])
            end_time = pd.to_datetime(constraint['timeRange'][1][:10])
        date_time = pd.to_datetime(detection_data_frame['datetime'])
        detection_data_frame = detection_data_frame[(start_time <= date_time) & (date_time <= end_time)]
        return detection_data_frame

    def get_detection_list(self) -> List[Dict[str, str]]:
        detection_list: List[Detection] = self.detection_mapper.select(QueryWrapper([]))
        return [item.json() for item in detection_list]

    def get_filtered_detection(self, constraint: Dict[str, List[str]]) -> List[Dict[str, str]]:
        detection_data_frame = self.get_filtered_data_frame(constraint)
        detection_dict_list: List[Dict[str, str]] = []
        for i in range(detection_data_frame.shape[0]):
            keys = detection_data_frame.columns
            values = detection_data_frame.iloc[i, :].values.ravel().tolist()
            detection_dict_list.append(
                Detection().init(name='detection', keys=keys, values=values).json()
            )
        return detection_dict_list

    def get_detection_data(self) -> List[Dict[str, str]]:
        detection_dict_list: List[Dict[str, str]] = self.detection_mapper.select_dict(QueryWrapper())
        return detection_dict_list

    def get_chart_data(self, chart_type: str, constraint: Dict[str, List[str]]) -> Any:
        detection_data_frame = self.get_filtered_data_frame(constraint)
        options = {
            'type': 'line',
            'title': {
                'text': '漂浮物数量的变化'
            },
            'bgColor': '#fbfbfb',
            'labels': ['2022-11-01', '2022-11-02', '2022-11-03', '2022-11-04', '2022-11-05'],
            'datasets': [
                {
                    'label': '漂浮物数量',
                    'data': [1, 2, 1, 3, 2]
                }
            ],
            'xRorate': 30
        }
        if chart_type == 'line':
            options['type'] = 'line'
            options['xRorate'] = 10
            options['title']['text'] = '漂浮物数量的变化'
            if len(detection_data_frame) == 0:
                options['labels'] = []
                options['datasets'] = []
                dataset = {
                    'label': '漂浮物数量',
                    'data': [],
                    'fillColor': '#2a598a'
                }
                options['datasets'].append(dataset)
                return options

            detection_data_frame['count'] = 1
            detection_data_frame.index = pd.to_datetime(detection_data_frame['datetime'])
            start_time = detection_data_frame.index[0]
            end_time = detection_data_frame.index[-1]

            def get_sample_interval(start, end, sample_count):
                seconds = (end - start).total_seconds()
                interval = seconds // sample_count
                return 1 if interval == 0 else interval

            sample_interval = get_sample_interval(start_time, end_time, 4)
            detection_data_frame = detection_data_frame.resample('{}S'.format(sample_interval)).sum(numeric_only=True)
            time_index = detection_data_frame.index.tolist()
            time_index = list(map(str, time_index))
            options['labels'] = time_index
            options['datasets'] = []
            dataset = {
                'label': '漂浮物数量',
                'data': detection_data_frame['count'].tolist(),
                'fillColor': '#2a598a'
            }
            options['datasets'].append(dataset)
        elif chart_type == 'bar':
            options['type'] = 'bar'
            options['xRorate'] = 20
            options['title']['text'] = '各监测点漂浮物数量'
            options['bgColor'] = '#fbfbfb'
            detection_data_frame['count'] = 1
            detection_data_frame = detection_data_frame[['river', 'count']]
            count = dict()
            for name, sheet in detection_data_frame.groupby('river'):
                count[name] = int(sheet['count'].sum())
            options['datasets'] = []
            options['labels'] = [camera.get('river') for camera in self.camera_mapper.select(QueryWrapper())]
            data = [count.get(river, 0) for river in options['labels']]
            dataset = {
                'label': '漂浮物数量',
                'data': data,
                'fillColor': '#412626'
            }
            options['datasets'].append(dataset)
        return options
