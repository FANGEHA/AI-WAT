import random
import time


class YoloService(object):
    def __init__(self):
        self.train_dict = dict()
        self.default = {
            'state': 0,
            'labels': [],
            'datasets': [
                {
                    'label': 'loss',
                    'data': [],
                    'fillColor': '#412626'
                },
                {
                    'label': 'val_loss',
                    'data': [],
                    'fillColor': '#7093DB'
                },
            ]
        }

    def upgrade(self, username):
        time.sleep(1)
        if len(self.train_dict[username]['labels']):
            x0 = eval(self.train_dict[username]['labels'][-1].split(' ')[0])
            loss0 = self.train_dict[username]['datasets'][0]['data'][-1]
            val_loss0 = self.train_dict[username]['datasets'][1]['data'][-1]
            x = str(x0 + 5) + ' epoch'
            loss = loss0 - (random.random() if random.randint(0, 2) else -random.random() * 0.7)
            val_loss = val_loss0 - (random.random() if random.randint(0, 2) else -random.random() * 0.7)
        else:
            x = str(5) + ' epoch'
            loss = random.randint(2, 3) + random.random()
            val_loss = random.randint(2, 3) + random.random()
        if len(self.train_dict[username]['labels']) > 10:
            self.train_dict[username]['state'] = 1
        self.train_dict[username]['labels'].append(x)
        self.train_dict[username]['datasets'][0]['data'].append(round(loss, 2))
        self.train_dict[username]['datasets'][1]['data'].append(round(val_loss, 2))

    def next(self, username):
        if username not in self.train_dict:
            self.train_dict[username] = self.default
        elif self.train_dict[username]['state'] == 1:
            self.train_dict[username] = self.default
        else:
            self.upgrade(username)
        return self.train_dict[username]
