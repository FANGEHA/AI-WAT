from flask import Blueprint, Response
import numpy as np
import cv2
from yolo.MyDection import ImageDetector

from service.CameraService import CameraService
from service.DetectionService import DetectionService

from config import *

file_blueprint = Blueprint('file', __name__)

detection_service = DetectionService(base_url, image_path, dataset_path)
camera_service = CameraService()

image_detector = ImageDetector()

def generate_and_detect():
    """Video streaming generator function."""
    yield b'--frame\r\n'
    while True:
        ret, current_image = camera_service.get_frame(camera_service.now_camera_idx)
        r_image, results = image_detector.detect(current_image)
        # if time.time() - last_insert_cache_time > 5:
        #     last_insert_cache_time = time.time()
        #     detection_service.insert_detection_results(results, now_river)
        current_image = np.array(r_image)
        frame = cv2.imencode('.jpg', current_image)[1].tobytes()
        yield b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n--frame\r\n'


# video
@file_blueprint.route('/videoFeed')
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(generate_and_detect(), mimetype='multipart/x-mixed-replace; boundary=frame')
