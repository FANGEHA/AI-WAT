from flask import Blueprint, request
from service.DetectionService import DetectionService
from config import *

detection_blueprint = Blueprint('detection', __name__)
detection_service = DetectionService(base_url, image_path, dataset_path)


@detection_blueprint.route('/detection/getLogList', methods=['POST'])
def get_log_list():
    try:
        res = detection_service.get_log_list()
        return res
    except:
        return '0'


@detection_blueprint.route('/detection/getDetectionList', methods=['POST'])
def get_detection_list():
    try:
        res = detection_service.get_detection_list()
        return res
    except:
        return '0'


@detection_blueprint.route('/detection/editDetectionItem', methods=['POST'])
def edit_detection_item():
    try:
        idx = request.json.get('idx')
        label = request.json.get('label')
        remark = request.json.get('remark')
        handle_state = request.json.get('handleState')
        return detection_service.edit_detection_item(idx, label, remark, handle_state)
    except:
        return '0'


@detection_blueprint.route('/detection/delDetectionItem', methods=['POST'])
def del_detection_item():
    try:
        idx = request.json.get('idx')
        detection_service.del_detection_item(idx)
        return '1'
    except:
        return '0'
