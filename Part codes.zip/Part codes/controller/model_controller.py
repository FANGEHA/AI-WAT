from flask import Blueprint, request
from service.CacheService import CacheService
from service.CameraService import CameraService
from service.YoloService import YoloService
from yolo.MyDection import ImageDetector
import io
from PIL import Image

model_blueprint = Blueprint('model', __name__)
cache_service = CacheService()
camera_service = CameraService()
image_detector = ImageDetector()
yolo_service = YoloService()

@model_blueprint.route('/model/upload', methods=['POST'])
def model_upload():
    global image_service
    f = request.files['file']
    byte_stream = io.BytesIO(f.read())
    pil_img = Image.open(byte_stream)
    image_url, image_index = image_service.save_dataset_img(
        username=cache_service.get_user_by_token(request.headers.get('Token')).get('username'),
        r_image=pil_img,
        xml_label=None)
    return image_url


@model_blueprint.route('/model/getImgList', methods=['POST'])
def get_img_list():
    global image_service
    user = cache_service.get_user_by_token(request.headers.get('Token'))
    return image_service.get_img_list(user.get('username'))


@model_blueprint.route('/model/getAugmentImgList', methods=['POST'])
def get_augment_img_list():
    global image_service
    user = cache_service.get_user_by_token(request.headers.get('Token'))
    return image_service.get_augment_img_list(user.get('username'))


@model_blueprint.route('/model/augment', methods=['POST'])
def augment():
    global image_service
    image_service.augment(
        username=cache_service.get_user_by_token(request.headers.get('Token')).get('username'),
        augment_type=request.json.get('augmentType'),
        extent=request.json.get('extent')
    )
    return '1'


@model_blueprint.route('/model/saveAugment', methods=['POST'])
def save_augment():
    global image_service
    user = cache_service.get_user_by_token(request.headers.get('Token'))
    image_service.save_augment(user.get('username'))
    return '1'


@model_blueprint.route('/model/getPlotData', methods=['POST'])
def get_plot_data():
    return yolo_service.next(cache_service.get_user_by_token(request.headers.get('Token')).get('username'))

