from flask import Blueprint, request
from service.DetectionService import DetectionService
from config import *

chart_blueprint = Blueprint('chart', __name__)
detection_service = DetectionService(base_url, image_path, dataset_path)


@chart_blueprint.route('/chart', methods=['POST'])
def chart():
    try:
        chart_type = request.json.get('chartType')
        constraint = request.json.get('constraint')
        return detection_service.get_chart_data(chart_type, constraint)
    except:
        return '0'
