from flask import Blueprint
from flask import request
from service.UserService import UserService
from config import *

user_blueprint = Blueprint('user', __name__)
user_service = UserService(base_url, image_path)

@user_blueprint.route('/user/getUserList', methods=['POST'])
def get_user_list():
    try:
        return user_service.get_user_list()
    except:
        return '0'


@user_blueprint.route('/user/createNewUser', methods=['POST'])
def create_new_user():
    try:
        username = request.json.get('username')
        password = request.json.get('password')
        type_ = request.json.get('type')
        user_service.create_new_user(username, password, type_)
        return '1'
    except:
        return '0'


@user_blueprint.route('/user/editUserPassword', methods=['POST'])
def edit_user_password():
    try:
        username = request.json.get('username')
        new_password = request.json.get('newPassword')
        user_service.edit_user_password(username, new_password)
        return '1'
    except:
        return '0'


@user_blueprint.route('/user/editUserType', methods=['POST'])
def edit_user_type():
    try:
        username = request.json.get('username')
        new_type = request.json.get('newType')
        user_service.edit_user_type(username, new_type)
        return '1'
    except:
        return '0'


@user_blueprint.route('/user/delUser', methods=['POST'])
def del_user():
    try:
        username = request.json.get('username')
        user_service.del_user(username)
        return '1'
    except:
        return '0'
