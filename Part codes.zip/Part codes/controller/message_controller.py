from flask import Blueprint, jsonify
from flask import request

message_blueprint = Blueprint('message', __name__)



@message_blueprint.route('/message/sysInfo', methods=['POST'])
def sys_info():
    global message_service
    try:
        return message_service.get_sys_info()
    except:
        return '0'


@message_blueprint.route('/message/handleOpinion', methods=['POST'])
def handle_opinion():
    global message_service
    try:
        return message_service.get_handle_opinion()
    except:
        return '0'


@message_blueprint.route('/message/addSysInfo', methods=['POST'])
def add_sys_info():
    global message_service
    try:
        username = request.json.get('username')
        type_ = 'sysInfo'
        title = request.json.get('title')
        content = request.json.get('content')
        message_service.insert_message(username=username, title=title, content=content, type_=type_)
        return '1'
    except:
        return '0'


@message_blueprint.route('/message/addHandleOpinion', methods=['POST'])
def add_handle_opinion():
    global message_service
    try:
        username = request.json.get('username')
        type_ = 'handleOpinion'
        title = request.json.get('title')
        content = request.json.get('content')
        message_service.insert_message(username=username, title=title, content=content, type_=type_)
        return '1'
    except:
        return '0'

