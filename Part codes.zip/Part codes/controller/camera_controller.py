from flask import Blueprint, request
from service.CameraService import CameraService

camera_blueprint = Blueprint('camera', __name__)
camera_service = CameraService()


@camera_blueprint.route('/camera/cameraList', methods=['POST'])
def camera_list():
    try:
        return camera_service.get_camera_dict_list()
    except:
        return '0'


@camera_blueprint.route('/camera/addCamera', methods=['POST'])
def add_camera():
    try:
        name = request.json.get('name')
        river = request.json.get('river')
        ip = request.json.get('ip')
        camera_service.insert_camera(name=name, river=river, ip=ip)
        return '1'
    except:
        return '0'


@camera_blueprint.route('/camera/switchCamera', methods=['POST'])
def switch_camera():
    try:
        new_idx = request.json.get('newIdx')
        camera_service.change_camera(new_idx)
        return '1'
    except:
        return '0'
